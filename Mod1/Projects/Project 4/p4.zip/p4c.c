/*
 * Charanjit Singh
 * Username: charans
 * CPSC 6810 MSCS Ready, Module 1, Fall 2023
 * Date: 9/23/2023
 * Project 4c
 * Code Summary:
 * Print a right triangle, composed of 'c' characters that fill the upper left diagonal.
 * It checks for number of rows in the range 1..80.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int args, char *argsv[]){
    // Defining a varaiable a to store user input
    int rows;
    // Defining i and t as loop counters
    int i, t;

    // if required argument is not provided, exit the loop
    if(args < 2){
        fprintf(stderr, "usage: ./p4c num_rows \n       num_rows in range 1..80 \n");
        exit(0);
    }
    // Converting the string input argument to int variable
    rows = atoi(argsv[1]);
    t = rows;

    // Checking if value of argument is valid
    if((rows < 1) || (rows > 80)){
        fprintf(stderr, "usage: ./p4c num_rows \n       num_rows in range 1..80 \n");
        exit(0);
    }   

    while(t > 0){
        for(i = t; i >=1; i--){
            printf("c");
        }
        printf("\n");
        t--;
    }

    return 0;
}