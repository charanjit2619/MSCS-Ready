/*
 * Charanjit Singh
 * Username: charans
 * CPSC 6810 MSCS Ready, Module 1, Fall 2023
 * Date: 9/23/2023
 * Project 4e
 * Code Summary:
 * Print a square that appears to be composed of 4 triangles (a, b, c and d) and a center '*'.
 * It also checks for number of rows in the range 1..80, it will also only accept odd numbers of rows.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int args, char *argsv[]){
    // Defining a varaiable a to store user input
    int rows;

    // Defining i and t as loop counters
    int i, j;

    // if required argument is not provided, exit the loop
    if(args < 2){
        fprintf(stderr, "usage: ./p4e num_rows \n       num_rows is odd in range 1..79 \n");
        exit(0);
    }

    rows = atoi(argsv[1]);

    if((rows < 1) || (rows >= 79) || (rows % 2 == 0)){
        fprintf(stderr, "usage: ./p4e num_rows \n       num_rows is odd in range 1..79 \n");
        exit(0);
    }   

    for(i = 1; i <= ((rows - 1)/2); i++){
        for(j = 1; j <= i; j++){
            printf("a ");
        }

        for(j = 1; j <= 2*(((rows - 1)/2) - i + 1) - 1; j ++){
            printf("b ");
        }

        for(j = 1; j <= i; j++){
            printf("d ");
        }
        printf("\n");
    }

    for(i = 1; i <= (rows+1)/2 - 1; i++){
        printf("a ");
    }

    printf("* ");

    for(i = 1; i <= (rows+1)/2 - 1; i++){
        printf("d ");
    }

    printf("\n");

    for(i = 1; i <= ((rows - 1)/2); i++){
        for(j = 1; j <= ((rows - 1)/2) - i + 1; j++){
            printf("a ");
        }

        for(j = 1; j <= 2*i - 1; j ++){
            printf("c ");
        }

        for(j = 1; j <= ((rows - 1)/2) - i + 1; j++){
            printf("d ");
        }
        printf("\n");
    }

    return 0;
}