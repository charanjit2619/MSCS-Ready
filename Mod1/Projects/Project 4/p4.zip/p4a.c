/*
 * Charanjit Singh
 * Username: charans
 * CPSC 6810 MSCS Ready, Module 1, Fall 2023
 * Date: 9/23/2023
 * Project 4a
 * Code Summary:
 * Print to the screen a right triangle with a user-specified number of rows.
 * It checks for number of rows in the range 1..80.
 */

#include <stdio.h>

int main(){
    // Defining a varaiable a to store user input
    int rows = 0;

    // Defining i and t as loop counters
    int i =1, t = 1;

    printf("This program will print a right triangle of 'a' characters.\nThe characters will appear in the lower left of the diagonal.\n");
 

    // Running the loop till we get a value between 1-80
    while((rows < 1) || (rows > 80)){
        printf("Enter the number of rows (1-80): ");
        scanf("%d", &rows);
    }    

    // Printing the right triangular pattern
    while(t <= rows){
        for(i = 1; i <= t; i++){
            printf("a");
        }
        printf("\n");
        t++;
    }
    return 0;
}