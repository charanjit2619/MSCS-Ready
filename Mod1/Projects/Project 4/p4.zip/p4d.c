/*
 * Charanjit Singh
 * Username: charans
 * CPSC 6810 MSCS Ready, Module 1, Fall 2023
 * Date: 9/23/2023
 * Project 4d
 * Code Summary:
 * Print a right triangle, composed of 'd' characters that fill the lower right diagonal
 * It checks for number of rows in the range 1..80.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int args, char *argsv[]){
    // Defining a varaiable a to store user input
    int rows;

    // Defining i and t as loop counters
    int i, j;

    // if required argument is not provided, exit the loop
    if(args < 2){
        fprintf(stderr, "usage: ./p4d num_rows \n       num_rows in range 1..80 \n");
        exit(0);
    }

    // Converting the string input argument to int variable
    rows = atoi(argsv[1]);

    // Checking if value of argument is valid
    if((rows < 1) || (rows > 80)){
        fprintf(stderr, "usage: ./p4d num_rows \n       num_rows in range 1..80 \n");
        exit(0);
    }   

    for (i = 1; i <= rows; i++) {
        // Print spaces
        for (j = 1; j <= rows - i; j++) {
            printf(" ");
        }

        // Print d for the triangle
        for (j = 1; j <= i; j++) {
            printf("d");
        }
        
        printf("\n");
    }

    return 0;
}